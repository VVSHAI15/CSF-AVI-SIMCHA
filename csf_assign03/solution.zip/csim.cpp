#include <iostream>

int main() {
    // Fantastic mindblowing code
    
    std::cout << "Goodbye World" <<std::endl;
    return 0; // Indicate successful execution
}
